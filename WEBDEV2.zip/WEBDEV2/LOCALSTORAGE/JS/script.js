document.addEventListener("DOMContentLoaded", () => {
    console.log("Hello World");
    displayMovie(); // Call displayMovie when the page loads
});

document.getElementById("btn").addEventListener("click", () => {    
    console.log("Button Clicked");

    let jsonString = JSON.stringify({
        "genre": document.getElementById("MovieGenre").value,
        "title": document.getElementById("MovieTitle").value
    });

    console.log(jsonString);

    localStorage.setItem("movie", jsonString);

    document.getElementById("displayGenre").innerHTML = document.getElementById("MovieGenre").value;
    document.getElementById("displayTitle").innerHTML = document.getElementById("MovieTitle").value;
    displayMovie(); // Call displayMovie to update the page immediately
});

document.getElementById("btn2").addEventListener("click", () => {    
    console.log("Button Clicked");

    document.getElementById("MovieGenre").value = "";
    document.getElementById("MovieTitle").value = "";
    document.getElementById("displayGenre").innerHTML = "Movie Genre";
    document.getElementById("displayTitle").innerHTML = "Movie Title";
    localStorage.removeItem("movie");
});

function displayMovie() {
    let retrievedObject = localStorage.getItem("movie");
    if (retrievedObject) {
        let parsedObject = JSON.parse(retrievedObject);

        let genre = parsedObject.genre;
        let title = parsedObject.title;

        console.log(genre);
        console.log(title);

        // Display the values on the page
        document.getElementById("displayGenre").innerHTML;
        document.getElementById("displayTitle").innerHTML;
    }
}

// Storing data
let entryKey = 'entry_' + Date.now(); // Generate a unique key
localStorage.setItem(entryKey, JSON.stringify({ name: "New Entry", value: "New Value" }));

// Retrieving data
for (let i = 0; i < localStorage.length; i++) {
  let key = localStorage.key(i);
  if (key.startsWith('entry_')) {
    let entry = JSON.parse(localStorage.getItem(key));
    console.log(key, entry);
  }
}
