const disneyCharacters = ['Mickey', 'Minnie', 'Donald', 'Daisy', 'Goofy', 'Pluto']

function getCharacters() {
  
    dropdown.innerHTML = ""
    disneyCharacters.sort()
  for (let i = 0; i < disneyCharacters.length; i++) {
    dropdown.innerHTML += `<option value=${i}>${disneyCharacters[i]}</option>`
  }
}

document.getElementById("choices").addEventListener("click", getCharacters) 

const dropdown = document.getElementById("dropdown")
dropdown.addEventListener("change", removeChoice) 

function removeChoice()
{
    disneyCharacters.splice(dropdown.value, 1)
    console.log(disneyCharacters)
}