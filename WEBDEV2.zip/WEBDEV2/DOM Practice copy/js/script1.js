

//my code


// Change all images when button is clicked
document.getElementById("myButton").addEventListener("click", function() {
    changeAllImages();
});

let colorPickerElement = document.getElementById("colorPicker");


/**
 * Function to change the background color based on the selected value from the color picker.
 */
function changeBackgroundColor() {
    var selectedColor = colorPickerElement.value;
    console.log(`Background color changed to: ${selectedColor}`); // Debugging Log
    document.body.style.backgroundColor = selectedColor;
}

let selectElement = document.getElementById('colorPicker');
let inputField = document.getElementById("messageInput");

/**
 * Function to update the background color based on the input field value.
 * Adds the new color to the dropdown options if it is not empty.
 */
function updateBackgroundColor() {
    var color = inputField.value.trim();

    console.log(`User typed color: "${color}"`); // Debugging Log

    if (color) {
        document.body.style.backgroundColor = color;
        console.log("Background color updated successfully!"); // Debugging Log
    } else {
        console.log("No color input detected."); // Debugging Log
    }

    // Add the color to the background color select form
    let option = document.createElement('option');
    option.textContent = color;
    option.value = color;
    selectElement.appendChild(option);
}





// Predefined color options for the dropdown
let options = ["White", "Pink", "Blue", "Green", "Yellow"];



options.forEach(optionValue => {
    let option = document.createElement('option');
    option.textContent = optionValue;
    option.value = optionValue;
    selectElement.appendChild(option);
});


let imagesCurrent = ["imgs/image1.jpg", "imgs/image2.jpg", "imgs/image3.jpg", "imgs/image4.jpg"];
let imagesNew = ["imgs/image5.jpg", "imgs/image6.avif", "imgs/image7.jpg", "imgs/image8.jpeg"];
let altTextsCurrent = ["Image 1", "Image 2", "Image 3", "Image 4"];
let altTextsNew = ["New Image 1", "New Image 2", "New Image 3", "New Image 4"];

function changeAllImages() {
    if (imagesCurrent.length !== imagesNew.length || altTextsCurrent.length !== altTextsNew.length) {
        console.error("The length of imagesCurrent, imagesNew, altTextsCurrent, and altTextsNew arrays do not match.");
        return;
    }
    for (let i = 0; i < imagesCurrent.length; i++) {
        let imgElement = document.querySelectorAll('img')[i];
        imgElement.src = imagesNew[i];
        imgElement.alt = altTextsNew[i];
    }
}