

// Arrays for image file paths
let currentImages = ["imgs/image1.jpg", "imgs/image2.png", "imgs/image3.avif", "imgs/image4.jpg"];
let newImages = ["imgs/image5.jpg", "imgs/image6.avif", "imgs/image7.jpg", "imgs/image8.jpeg"];

// Function to update images on page load
function updateImagesOnLoad() {
    let imageElements = document.querySelectorAll('img');
    imageElements.forEach((img, index) => {
        img.src = currentImages[index];
    });
}


// Button function to update image src attributes from the second array
function updateImages() {
    let imageElements = document.querySelectorAll('img');
    imageElements.forEach((img, index) => {
        img.src = newImages[index];
        console.log(`Updated image ${index + 1} to ${newImages[index]}`);
    });
}

// Add event listener to the button
document.getElementById('updateImagesButton').addEventListener('click', updateImages);

// Array of colors to populate the <select> dropdown
let colors = ["White", "Pink", "Blue", "Green", "Yellow"];

// Function to populate the <select> dropdown
function populateColorDropdown() {
    let selectElement = document.getElementById('colorSelect');
    selectElement.innerHTML = ''; // Clear existing options
    colors.forEach(color => {
        let option = document.createElement('option');
        option.textContent = color;
        option.value = color;
        selectElement.appendChild(option);
    });
}

// Call the function to populate the dropdown on page load
populateColorDropdown();

// Ensure onchange works dynamically when new colors are added
document.getElementById('colorSelect').addEventListener('change', function() {
    document.body.style.backgroundColor = this.value;
});

// Implement an input field that accepts colors and updates the colors array and <select> dropdown
document.getElementById('colorInput').addEventListener('blur', function() {
    let newColor = this.value;
    if (newColor) {
        document.body.style.backgroundColor = newColor;
    }

    colors.push(newColor);
    populateColorDropdown();
    this.value = ''; // Clear the input field
    
    console.log(`Added new color: ${newColor}`);
});



