//PROBLEM: Change the color of a paragraph when the button is clicked.
let dropdown = document.getElementById("changeColor");
function changeParagraphColor() {
  let paragraph = document.querySelector("#myParagraph"); 
  paragraph.style.color = dropdown.value
}

dropdown.addEventListener("change", changeParagraphColor);