//PROBLEM: Change the image's `src` to a new one when the button is clicked.

function updateImageSrc() {
  let img = document.querySelector("#image1");
  img.src = "imgs/stitch.jpg"; 
}

document.getElementById("button1").addEventListener("click", updateImageSrc);