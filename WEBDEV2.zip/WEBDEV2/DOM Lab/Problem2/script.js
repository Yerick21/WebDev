// PROBLEM: Update the text in a paragraph with the value from an input field.


function updateParagraph() {
  let input = document.getElementById("inputField").value;
  let paragraph = document.getElementById("paragraph1");
  paragraph.innerText = input;
  console.log(paragraph.innerText);
}

document.getElementById("button1").addEventListener("click", updateParagraph);
