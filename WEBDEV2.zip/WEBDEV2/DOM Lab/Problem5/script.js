//PROBLEM: Update the text of the second paragraph when the button is clicked.

function updateSpecificParagraph() {
  let paragraph = document.querySelector("targetParagraph"); 
  let inputText = document.getElementById('newText').value;
  paragraph.innerText = inputText;
}


document.getElementById('newText').addEventListener("click", updateSpecificParagraph);