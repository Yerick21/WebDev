// PROBLEM: Extract the first three items from the array without overwriting the original array.


function getFirstThree() {
    let animals = ["Dog", "Cat", "Bird", "Fish", "Horse"];
    let firstThree = animals.slice(0, 3); 

    document.getElementById("output").innerText =
        "First three animals: " + firstThree.join(", ") +
        "\nOriginal array: " + animals.join(", ");
}

document.getElementById("Get").addEventListener("click", getFirstThree);

// changed from splice to slice to not overwrite the original array.