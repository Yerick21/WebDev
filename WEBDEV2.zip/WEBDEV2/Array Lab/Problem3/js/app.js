// PROBLEM: Add a new item to the beginning of the array and display the updated array.


function addToBeginning() {
    let colors = ["Red", "Blue", "Green"];
    colors.unshift("Yellow"); 

    document.getElementById("output").innerText = "Colors: " + colors.join(", ");
}

document.getElementById("Add").addEventListener("click", addToBeginning);

// added the unshift method to add a new item to the beginning of the array.
// added the event listener to the button to call the function when clicked.