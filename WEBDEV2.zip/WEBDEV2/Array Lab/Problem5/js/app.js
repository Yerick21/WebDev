// PROBLEM: Add a new item to the array and display the updated array as a string.


function addItem() {
    let fruits = ["Apple", "Banana", "Cherry"];
    fruits.push("Orange"); 

    document.getElementById("output").innerText = "Fruits: " + fruits.join(", ");
}
document.getElementById("Add").addEventListener("click", addItem);

// added push insted add to add the new item to the array.