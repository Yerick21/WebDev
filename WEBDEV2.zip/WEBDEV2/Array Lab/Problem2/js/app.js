// PROBLEM: Calculate and display the sum of all numbers in the array.

function calculateSum() {
    let numbers = [10, 20, 30];
    let sum = 0;



    for (let i = 0; i < numbers.length; i++) {
        sum += numbers[i];
    }
    
    document.getElementById("output").innerText = "Sum: " + sum;
  
}

document.getElementById("change").addEventListener("click", calculateSum);

//Corrected the path and deleted the quotation marks so it would not be a string