// PROBLEM: Display all items of the array in a paragraph separated by commas.

function showAllItems() {
    let colors = ["Red", "Blue", "Green", "Yellow"];
    let result = "";

    for (let i = 0; i < colors.length; i++) {
        result += colors[i] 

        if (i < colors.length - 1) {
            result += ", ";
        }
    }
    document.getElementById("output").innerText = result;

    
}
document.getElementById("showAll").addEventListener("click", showAllItems);

// added a event listener to the button to call the function showAllItems when the button is clicked.
// edited the for loop so instead of a -1 it is now a +1 to display all items in the array.
// added a if statement to check if the index is less than the length of the array -1 then add a comma and a space to the end of the item.
