// PROBLEM: Display all items in the array as a comma-separated string.


function displayItems() {
    let items = ["Pen", "Pencil", "Eraser", "Marker"];
    let result = "";

    for (let i = 0; i < items.length; i++) {
        result += items[i];
        if (i < items.length - 1) {
            result += ", ";
        }
    }

    document.getElementById("output").innerText = result;
}
document.getElementById("Add").addEventListener("click", displayItems);

// change the index from 1 to 0
// added event listener
