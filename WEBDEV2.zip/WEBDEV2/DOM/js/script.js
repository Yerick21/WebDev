// alert(innerHeight)

window.console.log("hi lol")

console.log(document.body)
let myH1object = document.getElementById("demo")
console.log(myH1object)


let myImageObject = document.querySelector("#UFC")
console.log(myImageObject)

myH1object.innerText = "new text"
myH1object.style.color = "white"
myH1object.style.backgroundColor="black"

function setProperty() {
    myH1object.innerText = myImageObject.alt;
    myImageObject.src = "imgs/fighters.webp"
}

//set property

document.getElementById("setProp").addEventListener("click", setProperty);

console.log(myImageObject);

