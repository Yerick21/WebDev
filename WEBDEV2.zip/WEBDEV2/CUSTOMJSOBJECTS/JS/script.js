const rabbit = {
    color: 'white',
    checkWatch() {
        console.log(`The ${this.color} rabbit checks his watch and exclaims, "I'm late!"`);
    }
};
rabbit.checkWatch();

const spaceship = {
    name: 'Millennium Falcon',
    launch() {
        return `You have launched the spaceship ${this.name}!`;
    }
};

console.log(spaceship.launch());

const shoppingCart = {
    contents: [],
    add(item) {
        this.contents.push(item);
    },

    remove(item) { 
        this.contents.splice(this.contents.indexOf(item), 1);
    }
};

shoppingCart.add('apple');
shoppingCart.add('orange');
shoppingCart.add('banana');
console.log(shoppingCart.contents);
shoppingCart.remove('apple');
console.log(shoppingCart.contents);

const lever = {
    stamp: "ACME",
    pull () {
        return `An anvil stamped ${this.stamp} drops on your head`;
    }
};

console.log(lever.pull());

const fighter = {
    name: "Pereira",
    health: 100,
    punch(opponent) { 
        return `The fighter ${this.name} punches ${opponent} and says "CHAMA"`;
    }
};

console.log(fighter.punch("Adesanya"));