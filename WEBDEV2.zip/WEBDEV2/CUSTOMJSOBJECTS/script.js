
const player = {
    name: "LeBron James",
    health: 150,
    strength: 25,
    xp: 0,
    describe() {
        // console.log(`${this.name} has ${this.health} health points and ${this.strength} as strength. My pet is ${myPet}`);
        return `${this.name} has ${this.health} health points, ${this.strength} as strength and ${this.xp} as experience points.`;
    }
};
// Player 1 is hit with an arrow
player.health -= 20;
//Player 1 equips a strength necklace
player.strength += 10;
//Mario learns a new skill
player.xp += 15;
console.log(player.describe());


// Dog object
const dog = {
    name: "Hermes",
    species: "Labrador",
    weight: 49,
    bark() {
        return "Grrr! Grrr!";
    }
};

console.log(`${dog.name} is a ${dog.species} dog weighing ${dog.weight} Lbs.`);
console.log(`Look, a cat! ${dog.name} barks: ${dog.bark()}`);


// Account object
const account = {
    name: "Alex",
    balance: 0,
    credit(amount) {
        this.balance += amount;
    },
    describe() {
        return `owner: ${this.name}, balance: ${this.balance}`;
    }

};

account.credit(250);
console.log(account.describe());
account.credit(-80);
console.log(account.describe());