document.addEventListener("DOMContentLoaded", () => {
  console.log("Hello World");

  const animalCrossingOBJ = {
    title: "Animal Crossing",
    developer: "Nintendo",
    genre: "Life Simulation",
    releaseYear: 2001,
    mainCharacters: ["Tom Nook", "Isabelle", "K.K. Slider", "Blathers"],
    features: {
      customization: true,
      multiplayer: true,
      seasonsChange: true,
      realTimeClock: true,
    },
    };

    console.log(animalCrossingOBJ)

    // const animalCrossingJsonString = '{"title":"Animal Crossing","developer":"Nintendo","genre":"Simulation","releaseYear":2001,"mainCharacters":["Tom Nook","Isabelle","K.K. Slider","Blathers"],"features":{"customization":true,"multiplayer":true,"seasonsChange":true,"realTimeClock":true}}';
    // console.log(animalCrossingJsonString);

    console.log("***** LocalStorage allows us to store data in the browser even when the browser is closed,  and access it later *****");

    let jsonString = JSON.stringify(animalCrossingOBJ);
    console.log(jsonString);

    localStorage.setItem("animalCrossing", jsonString);

    let retrievedObject = localStorage.getItem("animalCrossing");
    console.log(retrievedObject);

    let parsedObject = JSON.parse(retrievedObject);
    console.log(parsedObject);

    document.getElementById("title").innerText = parsedObject.title;
});                       

